library(testthat)
library(opentripplanner)

test_check("opentripplanner")
